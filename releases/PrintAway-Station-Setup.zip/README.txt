﻿======================================================================
                 PRINTAWAY COUNTER STATION SETUP
======================================================================

QUICK 1-MINUTE SETUP INSTRUCTIONS FOR NEW PC:

1. Connect your printer (USB or LAN) and make sure Windows can print to it.
2. Double-click: setup-new-pc.bat
   - Follow the short prompts to select your shop name and printer.
   - Choose 'Y' to enable Auto-Start so PrintAway starts when PC turns on.
3. Keep this window running or minimized while the shop is open.

Customers can scan your shop QR code to upload documents and print!
Support: Contact your PrintAway administrator.
======================================================================